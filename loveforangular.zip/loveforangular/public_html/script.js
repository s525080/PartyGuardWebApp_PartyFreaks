// Code goes here

var app = angular.module('sharing', []);

app.controller('ParentCtrl', function($scope) {
  $scope.user = {
    name: "Henri"
  };
   this.url = 'index2.html';
this.rurl = 'index.html';
});

app.factory('Holder', function() {
  return {
    value: 0
  };
});

app.controller('ChildCtrl', function($scope, Holder) {
  $scope.parentUser = $scope.$parent.user;
  $scope.Holder = Holder;
  $scope.increment = function() {
    $scope.Holder.value++;
  };
});

app.controller('ChildCtrl2', function($scope, Holder) {
  $scope.Holder = Holder;
  $scope.increment = function() {
    $scope.Holder.value++;
  };
});

app.controller('ChildCtrl3', function($scope, $rootScope) {
  $scope.name = "World";
  $scope.sync = function() {
    $rootScope.$emit("namechanged", $scope.name);
  };
  $scope.sync2 = function() {
    $rootScope.$broadcast("namechanged2", $scope.name);
  };
});

app.controller('ChildCtrl4', function($scope, $rootScope) {
  $scope.name = "World";
  var destroyHandler = $rootScope.$on("namechanged", function(event, name) {
    $scope.name = name;
  });
  $scope.$on('$destroy', destroyHandler);
  $scope.$on("namechanged2", function(event, name) {
    $scope.name = name;
  });
});