package com.nwmsu.service;

public class CalService {
	
	public int add(int i, int j){
		return i+j;
	}
	
	public int sstractionub(int i, int j){
		return i-j;
	}
	
	

}
