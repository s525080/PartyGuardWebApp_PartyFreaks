package com.nwmsu.service;

public class TestClient {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		CalServiceServiceStub stub = new CalServiceServiceStub();
		
		CalServiceServiceStub.Add params = new CalServiceServiceStub.Add();
		params.setI(25);
		params.setJ(30);
		
		CalServiceServiceStub.AddResponse resp = stub.add(params);
		
		int res = resp.getAddReturn();
		System.out.println(res);
	}

}
