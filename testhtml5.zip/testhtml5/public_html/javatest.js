

//          this.url = 'test.html';
//this.rurl = 'index.html';

  var app = angular.module('app', []);
app.controller('people', function($scope, $http) {
  $http.get('http://localhost:8383/testhtml5/database.json')
  .success(function(response) {
      $scope.persons = response.records;
  });
});